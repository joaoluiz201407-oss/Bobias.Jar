package com.bobias;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import java.util.EnumSet;
import java.util.List;

public class BobiasEntity extends Wolf {
    private int speechCooldown = 20 * 18;

    public BobiasEntity(EntityType<? extends Wolf> type, Level level) {
        super(type, level);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new FollowNearestPlayerGoal(this, 1.12D, 3.0F, 32.0F));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override public void tick() {
        super.tick();
        if (!level().isClientSide && --speechCooldown <= 0) {
            speechCooldown = 20 * (25 + random.nextInt(36));
            if (level() instanceof ServerLevel server) {
                List<Player> nearby = server.getEntitiesOfClass(Player.class, getBoundingBox().inflate(16));
                if (!nearby.isEmpty()) {
                    boolean second = random.nextBoolean();
                    server.playSound(null, blockPosition(),
                        second ? BobiasMod.FOFAAAOO.get() : BobiasMod.BOBIASS.get(),
                        SoundSource.NEUTRAL, 0.85F, 1.0F);
                    String line = second ? "Bobias fofaaaoo!" : "Bobias!";
                    for (Player p : nearby) p.displayClientMessage(Component.literal("§dBobias: §f" + line), false);
                }
            }
        }
    }

    private static class FollowNearestPlayerGoal extends Goal {
        private final BobiasEntity mob;
        private final double speed;
        private final float minDistance, maxDistance;
        private Player target;
        private int repathDelay;

        FollowNearestPlayerGoal(BobiasEntity mob, double speed, float minDistance, float maxDistance) {
            this.mob = mob; this.speed = speed; this.minDistance = minDistance; this.maxDistance = maxDistance;
            setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }
        @Override public boolean canUse() {
            Player p = mob.level().getNearestPlayer(mob, maxDistance);
            if (p == null || p.isSpectator() || mob.distanceToSqr(p) < minDistance * minDistance) return false;
            target = p; return true;
        }
        @Override public boolean canContinueToUse() {
            return target != null && target.isAlive() && !target.isSpectator()
                && mob.distanceToSqr(target) > minDistance * minDistance
                && mob.distanceToSqr(target) < maxDistance * maxDistance * 1.5;
        }
        @Override public void start() { repathDelay = 0; }
        @Override public void stop() { target = null; mob.getNavigation().stop(); }
        @Override public void tick() {
            if (target == null) return;
            mob.getLookControl().setLookAt(target, 10.0F, mob.getMaxHeadXRot());
            if (--repathDelay <= 0) {
                repathDelay = 10;
                mob.getNavigation().moveTo(target, speed);
            }
        }
    }
}
