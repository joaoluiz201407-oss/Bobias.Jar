package com.bobias;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(BobiasMod.MODID)
public class BobiasMod {
    public static final String MODID = "bobias";
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);

    public static final RegistryObject<EntityType<BobiasEntity>> BOBIAS = ENTITIES.register("bobias",
        () -> EntityType.Builder.of(BobiasEntity::new, MobCategory.CREATURE)
            .sized(0.7F, 1.0F).clientTrackingRange(8).build("bobias"));

    public static final RegistryObject<SoundEvent> BOBIASS = SOUNDS.register("bobiass",
        () -> SoundEvent.createVariableRangeEvent(id("bobiass")));
    public static final RegistryObject<SoundEvent> FOFAAAOO = SOUNDS.register("fofaaaoo",
        () -> SoundEvent.createVariableRangeEvent(id("fofaaaoo")));

    public static final RegistryObject<Item> BOBIAS_EGG = ITEMS.register("bobias_spawn_egg",
        () -> new BobiasSpawnItem(new Item.Properties().stacksTo(16)));

    public BobiasMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus); ITEMS.register(bus); SOUNDS.register(bus);
    }
    public static ResourceLocation id(String path) { return ResourceLocation.fromNamespaceAndPath(MODID, path); }
}
