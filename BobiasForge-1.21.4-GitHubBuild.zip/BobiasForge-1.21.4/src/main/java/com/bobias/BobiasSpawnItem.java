package com.bobias;

import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class BobiasSpawnItem extends Item {
    public BobiasSpawnItem(Properties properties) { super(properties); }
    @Override public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        var pos = context.getClickedPos().relative(context.getClickedFace());
        var bobias = BobiasMod.BOBIAS.get().create(level);
        if (bobias == null) return InteractionResult.FAIL;
        bobias.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, context.getRotation(), 0);
        level.addFreshEntity(bobias);
        Player player = context.getPlayer();
        if (player == null || !player.getAbilities().instabuild) context.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
