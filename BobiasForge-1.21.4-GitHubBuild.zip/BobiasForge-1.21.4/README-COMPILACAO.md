# Bobias — compilação automatizada

Alvo declarado: Minecraft Java 1.21.4, Forge 54.x e Java 21.

## Compilar pelo GitHub Actions

1. Crie um repositório no GitHub.
2. Extraia o ZIP e envie **o conteúdo da pasta `BobiasForge-1.21.4`** para a raiz do repositório (incluindo `.github`).
3. Abra a aba **Actions**.
4. Se necessário, habilite workflows para o repositório.
5. Execute **Build Bobias** em **Run workflow** ou faça um push na branch `main`/`master`.
6. Se a compilação passar, baixe o artefato `bobias-forge-1.21.4` no fim da execução. O JAR fica dentro dele.

## Estado real deste projeto

Este workflow apenas executa o Gradle e publica o JAR se a compilação terminar com sucesso. Ele não corrige erros automaticamente e não significa que o mod já foi testado no Minecraft.

O código original ainda é uma base inicial. Antes de considerar uma versão final, é necessário validar os registros de atributos da entidade, renderer/modelo/textura, item de invocação, sons e comportamento dentro de um mundo Forge 1.21.4. O modelo próprio do Bobia e as mecânicas de manga/pomares ainda não fazem parte desta versão.

Não instale um JAR como versão final sem passar pela compilação e pelo teste no jogo.
